package com.classicloner.runjs;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

import static com.classicloner.runjs.MyFunctions.GOT_PERMISSION_TO_WRITE;
import static com.classicloner.runjs.MyFunctions.MY_WRITE_EXTERNAL_STORAGE_CODE;
import static com.classicloner.runjs.MyFunctions.appName;
import static com.classicloner.runjs.MyFunctions.bookmarkFile;
import static com.classicloner.runjs.MyFunctions.configFile;
import static com.classicloner.runjs.MyFunctions.double_touch_js;
import static com.classicloner.runjs.MyFunctions.downloadFile;
import static com.classicloner.runjs.MyFunctions.long_touch_js;
import static com.classicloner.runjs.MyFunctions.resetConfig;
import static com.classicloner.runjs.MyFunctions.scriptFile;
import static com.classicloner.runjs.MyFunctions.settingFile;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    static WebView mWebView;
    ProgressBar progressBar;
    static String pageUrl = "https://www.google.com";//Default page
    static MyFunctions myfunctionList;
    final Context maincontext = this;
    private SwipeRefreshLayout mySwipeRefreshLayout;
    private Menu mMenu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Uri data = getIntent().getData();
        if (data != null) {
            pageUrl = data.toString();
        }
        myfunctionList = new MyFunctions();

        String lastLoaded = myfunctionList.readFromExtFile(bookmarkFile).trim();
        if( !lastLoaded.isEmpty()) {
            pageUrl = lastLoaded ;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        mySwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeContainer);
        mySwipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    Log.i("SWIPE", "onRefresh called from SwipeRefreshLayout");

                    // This method performs the actual data-refresh operation.
                    // The method calls setRefreshing(false) when it's finished.
                    mWebView.loadUrl(mWebView.getUrl());
                }
            });


        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
        final GestureDetector gestureDetector = new GestureDetector(this, new GestureListener(this));
        mWebView = (WebView) findViewById(R.id.activity_main_webview);
        mWebView.getSettings().setJavaScriptEnabled(true);
        //mWebView.setOnTouchListener(new View.OnTouchListener() {});

        mWebView.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);

                //for downloading directly through download manager
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setTitle(fileName);
                fileName=fileName.replace(".bin" , ".jpg");
                Log.d("CHECK", fileName);
                request.setDescription(appName);
                request.setDestinationInExternalPublicDir(downloadFile, fileName.replace(".bin" , ".jpg"));
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(request);
            }
        });

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // once the page loading is finished
                super.onPageFinished(view, url);
                progressBar.setVisibility(view.GONE);
                mySwipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(view.VISIBLE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                progressBar.setVisibility(view.GONE);
                mySwipeRefreshLayout.setRefreshing(false);
                Toast tst = Toast.makeText(MainActivity.this, "Error occurred while loading", Toast.LENGTH_SHORT);
                tst.show();
            }
        });
        mWebView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return gestureDetector.onTouchEvent(event);
            }
        });

        mWebView.loadUrl(pageUrl);
        // init stuff
        askForPermission();
        //downloadFile = getDir( "Downloads" ,MODE_PRIVATE).getAbsolutePath(); internal
        myfunctionList.load_scripts();
        settingFile = myfunctionList.createFolderInExternal(appName+"/Settings");
        downloadFile = myfunctionList.createFolderInExternal(appName+"/Downloads");
        scriptFile = myfunctionList.createFolderInExternal(appName+"/Scripts");
        configFile = myfunctionList.createFileInExternal(appName+"/Settings",".Cache");
        double_touch_js = myfunctionList.createFileInExternal(appName+"/Scripts","double_touch.js");
        long_touch_js = myfunctionList.createFileInExternal(appName+"/Scripts","long_touch.js");
        bookmarkFile = myfunctionList.createFileInExternal(appName+"/Settings",".bookmarks");
        if ( !new File(configFile).exists()) {
            configFile = myfunctionList.createFileInExternal(appName+"/Settings","Config.txt");
            myfunctionList.writeToExtFile( configFile ,resetConfig);
        }

        Log.d( "INFO" , Environment.getExternalStorageDirectory().getAbsolutePath());
        Log.d( "INFO" , downloadFile);
        Log.d( "INFO" , settingFile);
        Log.d( "INFO" , configFile);
    }

    /*********************** Start: Hard keys handlers     *****************************/
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) { //if back key is pressed
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) {
            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            if (drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START);
            }
            else {
                mWebView.goBack();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        Toast ts;
        switch (item.getItemId()) {
            case R.id.action_settings:
                ts = Toast.makeText(MainActivity.this, "Reload", Toast.LENGTH_SHORT);
                ts.show();
                return true;

            case R.id.nav_share:
                ts = Toast.makeText(MainActivity.this, "nav_share", Toast.LENGTH_SHORT);
                ts.show();
                return true;

            case R.id.nav_send:
                ts = Toast.makeText(MainActivity.this, "nav_send", Toast.LENGTH_SHORT);
                ts.show();
                return true;

            case R.id.about:
                ts = Toast.makeText(MainActivity.this, "about", Toast.LENGTH_SHORT);
                ts.show();
                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);
        }
    }


    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                    MainActivity.this);

            // set title
            alertDialogBuilder.setTitle("Close");

            // set dialog message
            alertDialogBuilder
                    .setMessage("Do you really want to exit?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // if this button is clicked, close
                            // current activity
                            MainActivity.this.finish();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // if this button is clicked, just close
                            // the dialog box and do nothing
                            dialog.cancel();
                        }
                    });

            // create alert dialog
            AlertDialog alertDialog = alertDialogBuilder.create();

            // show it
            alertDialog.show();
        }
    }

    /*********************** Done: Hard keys handlers   *****************************/

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        this.mMenu = menu;
        final SearchView searchView = (SearchView)menu.findItem(R.id.action_search).getActionView();
        searchView.setOnQueryTextListener(
                new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        searchView.setIconified(true);
                        searchView.clearFocus();
                        searchView.onActionViewCollapsed();
                        pageUrl = "https://www.google.co.in/search?q="+query.toString();
                        Log.d("QUERY" , pageUrl);
                        mWebView.loadUrl(pageUrl);

                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        //Log.d("QUERY" , "CHANGING: "+newText);
                        return false;
                    }
                }
        );
        return true;
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_console) {
            bringUpConsole("__NOJSDATA__");
            return true;
        } else if (id == R.id.nav_slideshow) {
            Toast.makeText(MainActivity.this, "Slideshow ", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_load) {
            Toast.makeText(MainActivity.this, "Pick the javascript file ", Toast.LENGTH_SHORT).show();
            myfunctionList.performFileSearch(maincontext);
        } else if (id == R.id.nav_share) {
            Toast.makeText(MainActivity.this, "Share ", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_send) {
            Toast.makeText(MainActivity.this, "Send ", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.config_reload) {
            Toast.makeText(MainActivity.this, "reloading script configuration ", Toast.LENGTH_SHORT).show();
            myfunctionList.load_scripts();
        } else if (id == R.id.nav_exit) {
            MainActivity.this.finish();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public boolean bringUpConsole(String jsData){
        Intent intent = new Intent(MainActivity.this,JSConsole.class);
        intent.putExtra("url", "https://www.instagram.com/accounts/login");
        intent.putExtra("jsData", jsData);
        startActivity(intent);
        return true;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {

        // The ACTION_OPEN_DOCUMENT intent was sent with the request code
        // READ_REQUEST_CODE. If the request code seen here doesn't match, it's the
        // response to some other intent, and the code below shouldn't run at all.

        if (requestCode == myfunctionList.READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            // The document selected by the user won't be returned in the intent.
            // Instead, a URI to that document will be contained in the return intent
            // provided to this method as a parameter.
            // Pull that URI using resultData.getData().
            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();
                Log.i("CHECK", "Uri: " + uri.toString());
                try {
                    String jsContent ;
                    myfunctionList.currentJsFile = uri.getLastPathSegment();
                    jsContent = myfunctionList.readTextFromUri(uri , maincontext);
                    bringUpConsole(jsContent);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else{
                Log.i("CHECK", "Nothing is selected");
            }
        }
    }

    public  void askForPermission(){
        /******************* Start: Request Permission Handling ********************************/
        // Check for the permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // get the permission
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_CONTACTS)) {
                String explanationStr = "This app need WRITE permisson to store the data in your phone";
                new android.app.AlertDialog.Builder(this).setTitle("Request").setMessage(explanationStr).setPositiveButton(android.R.string.ok, null).setCancelable(false).create().show();
            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_WRITE_EXTERNAL_STORAGE_CODE);
            }
        } else {
            Log.d("WRITE_PERM", "Permission is already granted");
            GOT_PERMISSION_TO_WRITE = 1;
        }
        /******************* Done: Request Permission Handling ********************************/
    }

    @Override
    public void onResume(){
        super.onResume();
    }

    @Override
    public  void onDestroy(){
        super.onDestroy();
        myfunctionList.writeToExtFile(bookmarkFile , mWebView.getUrl()+"\n");
    }
}

/*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        */
