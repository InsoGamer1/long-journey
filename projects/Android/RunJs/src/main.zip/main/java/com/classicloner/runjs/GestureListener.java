package com.classicloner.runjs;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.widget.Toast;

import static com.classicloner.runjs.MainActivity.mWebView;
import static com.classicloner.runjs.MyFunctions.double_touch_script;
import static com.classicloner.runjs.MyFunctions.long_touch_script;

public class GestureListener extends GestureDetector.SimpleOnGestureListener {
    private static final int SWIPE_THRESHOLD = 100;
    private static final int SWIPE_VELOCITY_THRESHOLD = 100;
    float xPos1;
    float yPos1;
    private Context context;
    public String resultLog="";
    AlertDialog.Builder alertDialogBuilder;

    public GestureListener(Context current){
        this.context = current;
        alertDialogBuilder = new AlertDialog.Builder(current);
    }

    @Override
    public void onLongPress(MotionEvent event) {
        float density = context.getResources().getDisplayMetrics().density; //Screen density
        xPos1 = event.getX() / density;  //Must be divided by the density of the screen
        yPos1 = event.getY() / density;
        Log.i("Touch LONG :" , "( " + xPos1 + ","+yPos1 +" )" );
        Toast.makeText(context, "(x,y):( " + xPos1 + ","+yPos1 +" )" , Toast.LENGTH_SHORT);
        clickImage(xPos1 , yPos1 , long_touch_script , "LONG");
        super.onLongPress(event);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent event) {
        super.onDown(event);
        return true;
        /*
        Toast.makeText(context, "Single Tap" , Toast.LENGTH_SHORT);
        clickImage(0 , 0 , double_touch_script , "SINGLE");
        */
    }

    @Override
    public boolean onDoubleTap(MotionEvent event) {
        Toast.makeText(context, "Double Tap" , Toast.LENGTH_SHORT);
        Log.i("Touch DOUBLE :" , "" );
        float density = context.getResources().getDisplayMetrics().density; //Screen density
        xPos1 = event.getX() / density;  //Must be divided by the density of the screen
        yPos1 = event.getY() / density;
        Log.i("Touch LONG :" , "( " + xPos1 + ","+yPos1 +" )" );
        clickImage(xPos1 , yPos1 , double_touch_script , "DOUBLE");
        super.onDoubleTap(event);
        return true;
    }

    private void clickImage(float touchX, float touchY , String js_data , final String event) {
        final String function_data ;

        function_data = "(\n" +
                    "function(){\n" +
                    "    console.log( \"(function(){ ... })();\");\n" +
                    "    _x = "+touchX+"; \n" +
                    "    _y = "+touchY+"; \n" +
                    "    console.log( \"variable _x and _y has positionX and positionY\" , _x , _y);\n" +
                    js_data+
                    "})();";
        Log.d( "FUNCTION" , function_data);

        // executing the javascript
        mWebView.evaluateJavascript(function_data, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String s) {
                Toast.makeText(context,s , Toast.LENGTH_SHORT).show();
            }
        });
        mWebView.setWebChromeClient(new WebChromeClient() {
            public boolean onConsoleMessage(ConsoleMessage cm) {
                resultLog += cm.message()+"\n@ "+cm.lineNumber()+" of "+cm.sourceId();
                Log.d( "Console" ,resultLog );

                return true;
            }
        });
        alertDialogBuilder.setTitle(event+":Output!");
        alertDialogBuilder.setMessage(resultLog);
        alertDialogBuilder.setCancelable(true)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Log.d( "pnclick" ,resultLog );
                        resultLog = "";
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


}
